﻿using System;

namespace FlightReport
{
    class Program
    {
        static void Main(string[] args)
        {
            //var service = new FlightService();

            //service.GetFlights();
            //service.GetDelayedFlights();

            Console.ReadLine();
        }
    }
}
