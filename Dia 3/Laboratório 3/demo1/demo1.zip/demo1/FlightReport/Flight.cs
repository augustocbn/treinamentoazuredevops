﻿using System;
using System.Collections.Generic;
using System.Text;
using System;

namespace FlightReport
{
    public class Flight
    {
        public string Number { get; set; }
        public DateTime Date { get; set; }
    }
}
