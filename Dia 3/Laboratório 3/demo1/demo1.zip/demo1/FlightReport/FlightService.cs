﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightReport
{
    public class FlightService
    {
        //public IEnumerable<Flight> GetDelayedFlights()
        //{
        //    yield return new Flight { Number = "0001", Date = DateTime.Now };
        //    yield return new Flight { Number = "0002", Date = DateTime.Now };
        //    yield return new Flight { Number = "0003", Date = DateTime.Now };
        //}

        //public IEnumerable<Flight> GetFlights()
        //{
        //    yield return new Flight { Number = "0004", Date = DateTime.Now };
        //    yield return new Flight { Number = "0005", Date = DateTime.Now };
        //}
    }
}
