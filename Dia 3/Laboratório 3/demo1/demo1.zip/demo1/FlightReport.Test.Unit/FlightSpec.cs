using System;
using Xunit;
using FluentAssertions;
using System.Linq;

namespace FlightReport.Test.Unit
{
    public class FlightSpec
    {
        [Fact]
        public void ShouldHaveTwoFlights()
        {
            // Given
            var service = new FlightService();

            // When
            var flights = service.GetFlights().ToList();

            // Then
            flights.Count.Should().Be(2);
        }
    }
}
