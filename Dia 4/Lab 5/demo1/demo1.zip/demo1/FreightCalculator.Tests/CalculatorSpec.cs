using System;
using Xunit;

namespace FreightCalculator.Tests
{
    public class CalculatorSpec
    {
        [Fact]
        public void ShouldCalculate()
        {
            // Given
            var calculator = new Calculator();

            // When
            var result = calculator.Calculate("29102888");

            // Then
            Assert.True(result == 1.3m);
        }
    }
}
