﻿using System;

namespace FreightCalculator
{
    public class Calculator
    {
        public decimal Calculate(string address)
        {
            return 1.3m;
        }
    }
}
